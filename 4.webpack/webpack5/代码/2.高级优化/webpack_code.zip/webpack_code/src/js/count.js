export default function count(x, y) {
  return x - y;
}
