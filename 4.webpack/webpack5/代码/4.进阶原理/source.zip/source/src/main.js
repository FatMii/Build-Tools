import "./css/index.css";

console.log("hello main");

console.log("hello 111");
console.log("hello 222");

const sum = (...args) => {
  return args.reduce((p, c) => p, c, 0);
};
